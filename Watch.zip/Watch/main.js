const bigImg = document.querySelector('.big-img');
const container = document.querySelector('.container-fluid');
let contentChange = document.querySelector('.content');

//create a function //
function myWatchs(watch) {
    bigImg.src = watch;
}

// change background color
function backGround(color) {
    container.style.background = color;
}

//change text color //
function textChange(color) {
    contentChange.style.color = color;
}
